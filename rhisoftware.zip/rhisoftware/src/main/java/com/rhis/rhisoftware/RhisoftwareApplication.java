package com.rhis.rhisoftware;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RhisoftwareApplication {

	public static void main(String[] args) {
		SpringApplication.run(RhisoftwareApplication.class, args);
	}

}
